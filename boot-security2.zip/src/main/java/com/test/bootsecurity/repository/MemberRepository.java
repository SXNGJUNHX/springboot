package com.test.bootsecurity.repository;

public interface MemberRepository {
}
