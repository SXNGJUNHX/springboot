package com.test.bootsecurity.controller;

public class MemberController {
}
