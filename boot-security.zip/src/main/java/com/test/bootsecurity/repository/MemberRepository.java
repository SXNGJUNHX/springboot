package com.test.bootsecurity.repository;

public class MemberRepository {
}
