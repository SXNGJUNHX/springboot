package com.test.bootsecurity.service;

public class MemberService {
}
